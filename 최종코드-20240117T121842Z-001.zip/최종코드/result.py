from collections import defaultdict

data=[]
idx_and_data=[]
data_len=0
selected_idx=0
selected_row=[]
name_num_dict=defaultdict(list)
num_pack_dict=defaultdict(list)

a=(1,2,3,4)
b=(11,22,33,44)
c=a+b
print(c)
