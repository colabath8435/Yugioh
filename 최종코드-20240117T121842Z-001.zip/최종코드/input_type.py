class input_data:
    def __init__(self):
        self.min_level
        self.max_level
        self.ATK_MIN
        self.ATK_MAX
        self.DEF_MIN
        self.DEF_MAX
        self.atr_list = []
        self.icon_list = []
        self.type_list = []

