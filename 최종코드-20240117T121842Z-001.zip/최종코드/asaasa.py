print(['abcd'])
print(list('abcd'))